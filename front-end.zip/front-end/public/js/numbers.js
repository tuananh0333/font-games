$(document).ready(function() {
    play(100);
});

function newTop() {return Math.floor(Math.random() * 950);}
function newLeft() {return 200 + Math.floor(Math.random() * 1600);}

function play(maxScore) {
    var arrTop = [];
    var arrLeft = [];

    var currentNum = 1;
    var validTries = 4;
    var scoreColors = ["red", "orange", "yellow", "yellowgreen", "black"];

    $(".score").css("color",scoreColors[validTries]);
    $(".number").remove();
    $(".result").css("display","none");
    $(".hide").css("display","none");

    for (var index = 1; index <= maxScore; index++) {
        var top = newTop();
        var left = newLeft();

        while((arrTop.indexOf(top) != -1)) {top += 32}
        while(arrLeft.indexOf(left) != -1) {left = newLeft()}

        arrTop[index-1] = top;
        arrLeft[index-1] = left;

        // var top = Math.floor(Math.random() * 950);
        // while(arrTop.find(function(element) {
        //     return ((top > element) && (top < element+32)) || ((element > top) && (element < top+32));
        // }) && arrTop.length > 0) {
        //     top = Math.floor(Math.random() * 950);
        // } 
        // arrTop[index-1] = top;

        // var left = 200 + Math.floor(Math.random() * 1600);
        // while(arrLeft.find(function(element) {
        //     return ((left > element) && (left < element+32)) || ((element > left) && (element < left+32));
        // }) && arrLeft.length > 0) {
        //     left = 200 + Math.floor(Math.random() * 1600);
        // } 
        // arrLeft[index-1] = left;

        $("body").append("<div class='number' style='top: " + top + "px; left: " + left + "px;'>"+index+"</div>");        

        $(".score").text(currentNum-1);
    }

    $(".number").click(function() {
        if($(this).text() == currentNum) {
            $(this).css("display","none");
            $(".score").text(currentNum);
            currentNum++;
        } else {
            if(validTries == 0) {
                $(".result").text("GAME OVER...");
                $(".result").css("display","block");
                $(".hide").css("display","block");
                var numbers = $(".number").siblings();
                for (let index = 0; index < numbers.length; index++) {
                    if (numbers.eq(index).text() == currentNum) {
                        numbers.eq(index).css("background","red");
                        numbers.eq(index).css("color","#fff");
                    }
                }
            } else {
                validTries--;
                $(".score").css("color",scoreColors[validTries]);
            }
        }
        if(currentNum-1 == maxScore) {
            $(".result").text("YOU WON!!!");
            $(".result").css("display","block");
            $(".hide").css("display","block");
        } 
    });

    $(".result").click(function () {
        play(maxScore);
    });
}