$(document).ready(function () {
    var blockChilds = $(".block").children();
    var rowsNum = (blockChilds.length);

    $(".child").css("width",(100/rowsNum)+"%");
});